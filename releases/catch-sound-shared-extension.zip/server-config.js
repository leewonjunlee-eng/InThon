export const SERVER_CONFIG = {"serverUrl": "https://catch-sound-ai.vercel.app", "token": "lLZLs52edu2p1wDK5Uc3-fPpFwxLI8HPdl4kqJyONic"};
